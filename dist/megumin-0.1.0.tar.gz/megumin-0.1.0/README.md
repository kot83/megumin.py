An unofficial wrapper for [megumin.torque.ink](https://megumin.torque.ink/)

Example:
```py
import megumin
result = megumin.get_megumin(useragent='Megumin.py/v0.1.0/Development')
print('Chant: '+result['chant'])
print('Image URL: '+result['img'])
```
